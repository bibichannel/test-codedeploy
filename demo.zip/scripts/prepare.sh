#!/bin/bash

#mkdir -p /var/www/html/assetz-serverside-3/
#cp -r /home/ec2-user/deployment/* /var/www/html/assetz-serverside-3/

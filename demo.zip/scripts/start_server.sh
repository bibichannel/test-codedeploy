#!/bin/bash

sudo nginx -s reload